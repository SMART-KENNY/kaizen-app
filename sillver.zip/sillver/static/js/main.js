// ── State ─────────────────────────────────────────────────────────────────────
const entries = [];  // [{ table, partition_col, enabled }]

// ── Helpers ───────────────────────────────────────────────────────────────────
function tableToVar(table) {
  const last = table.trim().split(".").pop();
  return last.replace(/[^\w]/g, "_") + "_name";
}
function varToDf(v) {
  return v.endsWith("_name") ? v.slice(0, -5) + "_df" : v + "_df";
}
function escapeHtml(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function csvToArray(str) {
  return str.split(",").map(s => s.trim()).filter(Boolean);
}

// ── Source Table management ───────────────────────────────────────────────────
function addEntry(tableStr) {
  const t = tableStr.trim().replace(/^[,;]+|[,;]+$/g, "");
  if (!t || entries.find(e => e.table === t)) return;
  entries.push({ table: t, partition_col: "processed_date", enabled: true });
  renderList();
  updatePreview();
}
function removeEntry(i) {
  entries.splice(i, 1);
  renderList();
  updatePreview();
}
function toggleFilter(i) {
  entries[i].enabled = !entries[i].enabled;
  renderList();
  updatePreview();
}
function updatePartitionCol(i, val) {
  entries[i].partition_col = val;
  updatePreview();
}
function commitInput() {
  const input = document.getElementById("tag-input");
  input.value.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean).forEach(addEntry);
  input.value = "";
  input.focus();
}

// ── Render source table list ──────────────────────────────────────────────────
function renderList() {
  const container = document.getElementById("table-list");
  container.innerHTML = "";
  entries.forEach((entry, i) => {
    const varName = tableToVar(entry.table);
    const dfName  = varToDf(varName);
    const active  = entry.enabled;
    const row = document.createElement("div");
    row.className = "table-row";
    row.innerHTML = `
      <div class="table-info">
        <div class="table-path" title="${escapeHtml(entry.table)}">${escapeHtml(entry.table)}</div>
        <div class="table-vars">
          <span class="v-name">${escapeHtml(varName)}</span>
          <span style="color:var(--muted)"> · </span>
          <span class="v-df">${escapeHtml(dfName)}</span>
        </div>
      </div>
      <div class="table-arrow">→</div>
      <div class="partition-group">
        <div class="partition-label">Partition column</div>
        <div class="partition-input-wrap ${active ? "" : "no-filter"}">
          <input class="partition-input" type="text"
            value="${escapeHtml(entry.partition_col)}"
            placeholder="none"
            ${active ? "" : "disabled"}
            oninput="updatePartitionCol(${i}, this.value)"/>
          <button class="btn-filter-toggle ${active ? "on" : "off"}"
            title="${active ? "Disable filter" : "Enable filter"}"
            onclick="toggleFilter(${i})">${active ? "⊙" : "⊘"}</button>
        </div>
      </div>
      <button class="btn-remove-row" onclick="removeEntry(${i})" title="Remove">×</button>`;
    container.appendChild(row);
  });
}

// ── Code Preview (cells 33, 34, 42) ──────────────────────────────────────────
function updatePreview() {
  const strip = document.getElementById("preview-strip");
  const body  = document.getElementById("preview-body");
  if (!entries.length) { strip.classList.remove("visible"); return; }
  strip.classList.add("visible");

  const lines = [];
  lines.push('<span class="cm"># Cell 33 — source table assignments</span>');
  entries.forEach(e => {
    const v = tableToVar(e.table);
    lines.push(`<span class="kw">${v}</span> = <span class="st">"${escapeHtml(e.table)}"</span>`);
  });
  lines.push("");
  entries.forEach(e => {
    const v = tableToVar(e.table);
    lines.push(`${v} = DU.retreive_table_name_by_environment(execution_environment, ${v})`);
  });

  const dfParams = entries.map(e => varToDf(tableToVar(e.table))).join(", ");
  lines.push("");
  lines.push('<span class="sec"><span class="cm"># Cell 34 — transform_data signature</span></span>');
  lines.push(`<span class="kw">def</span> transform_data(<span class="df">${escapeHtml(dfParams)}</span>):`);

  lines.push("");
  lines.push('<span class="sec"><span class="cm"># Cell 42 — spark.read.table blocks</span></span>');
  entries.forEach(e => {
    const v  = tableToVar(e.table);
    const df = varToDf(v);
    if (e.enabled && e.partition_col) {
      lines.push(
        `<span class="df">${df}</span> = spark.read.table(<span class="kw">${v}</span>).filter(\n` +
        `    F.col(<span class="st">"${escapeHtml(e.partition_col)}"</span>) == F.lit(file_timestamp_str)\n)`
      );
    } else {
      lines.push(`<span class="df">${df}</span> = spark.read.table(<span class="kw">${v}</span>)`);
    }
    lines.push("");
  });

  body.innerHTML = lines.join("\n");
}

// ── Build config JSON object ──────────────────────────────────────────────────
function buildConfigObject() {
  const v = id => document.getElementById(id).value.trim();
  const b = id => document.getElementById(id).value === "true";

  const appName       = v("cfg-app-name")           || "<Application_Name>";
  const tableName     = v("cfg-table-name")          || "<Table_Name>";
  const refreshCols   = csvToArray(v("cfg-refresh-cols"));
  const clusterCols   = csvToArray(v("cfg-clustering-cols"));
  const saveMode      = v("cfg-save-mode")           || "append";
  const partOverwrite = b("cfg-partition-overwrite");
  const dqCol         = v("cfg-dq-column")           || "<check_null_target_column>";
  const dqEmail       = b("cfg-dq-email");
  const dqTeams       = b("cfg-dq-teams");
  const dqSnow        = b("cfg-dq-snow");

  return {
    application_name: appName,
    logger_configuration: { log_level: "DEBUG" },
    task_configuration: {
      datasource_configuration: {},
      endpoint_configuration: {
        table_name: tableName,
        data_refresh_column_list: refreshCols.length ? refreshCols : ["<data_refresh_column_list>"],
        liquid_clustering_column_list: clusterCols.length ? clusterCols : ["<liquid_clustering_column>"],
        save_mode: saveMode,
        partition_overwrite_flag: partOverwrite
      },
      data_standardization_configuration: [],
      data_quality_configuration: [
        {
          rule_name: "check_null",
          target_column: dqCol,
          parameters: {},
          action: "log",
          execution_stage: "transformed",
          send_email_notifications: dqEmail,
          send_teams_notifications: dqTeams,
          raise_servicenow_tickets: dqSnow
        }
      ]
    },
    utility_configuration: {}
  };
}

// ── JSON syntax highlighter ───────────────────────────────────────────────────
function highlightJson(obj) {
  const raw = JSON.stringify(obj, null, 4);
  // Escape HTML first
  let escaped = raw
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");

  // Apply token colours
  return escaped.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    match => {
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          // key — strip quotes & colon for display, but keep structure
          return `<span class="jp-key">${match}</span>`;
        }
        // string value — highlight placeholder <...>
        const inner = match.replace(/&lt;[^&]*&gt;/g, m => `<span class="jp-ph">${m}</span>`);
        return `<span class="jp-str">${inner}</span>`;
      }
      if (/true|false/.test(match)) return `<span class="jp-bool">${match}</span>`;
      if (/null/.test(match))       return `<span class="jp-null">${match}</span>`;
      return `<span class="jp-num">${match}</span>`;
    }
  );
}

// ── Live JSON preview ─────────────────────────────────────────────────────────
function updateJsonPreview() {
  const pre = document.getElementById("json-preview");
  const cfg = buildConfigObject();
  pre.innerHTML = highlightJson(cfg);
}

// ── Copy JSON to clipboard ────────────────────────────────────────────────────
function copyJson() {
  const cfg = buildConfigObject();
  navigator.clipboard.writeText(JSON.stringify(cfg, null, 4)).then(() => {
    const btn = document.querySelector(".btn-copy-json");
    btn.textContent = "✓ Copied";
    setTimeout(() => { btn.innerHTML = `<svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>Copy`; }, 1800);
  });
}

// ── Download config.json ──────────────────────────────────────────────────────
function downloadConfig() {
  const cfg  = buildConfigObject();
  const name = document.getElementById("nb-name").value.trim() || "generated_notebook";
  const blob = new Blob([JSON.stringify(cfg, null, 4)], { type: "application/json" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `${name}.json`;
  a.click();
  URL.revokeObjectURL(url);
  setStatus("✓ config.json downloaded!", "success");
}

// ── Build YAML string ─────────────────────────────────────────────────────────
function buildYamlString() {
  const v    = id => document.getElementById(id)?.value?.trim() ?? "";
  const num  = id => parseInt(document.getElementById(id)?.value) || 0;

  const appName        = v("cfg-pipeline-name")         || "<Pipeline_Name>";
  const dataDomainName = v("cfg-datadomain-name").split("_")[0]  || "<Data_Domain_Name>";
  const frequency      = v("yml-frequency")             || "daily";
  const jobCategory    = v("yml-job-category")          || "<job_category>";
  const timeout        = num("yml-timeout");
  const healthThr      = num("yml-health-threshold");
  const maxConcurrent  = num("yml-max-concurrent");
  const maxRetries     = num("yml-max-retries");

  // Config paths — auto-fill from appName if user hasn't overridden
  const configPath     = v("yml-config-path")
    || `../etc/${appName}_config.json`;
  const downstreamPath = v("yml-downstream-config-path")
    || `./${dataDomainName}/etc/${appName}_config.json`;

  const jobKey   = `wde_${appName}_silver_job`;
  const taskKey  = `${appName}_silver_task`;

  return `resources:
  jobs:
    ${jobKey}:
      name: ${jobKey}
      webhook_notifications: \${var.webhook_notifications_config}
      tags:
        owner: Wireless Data Engineering
        layer: silver
        job_type: ${frequency}
        job_category: ${jobCategory}
      permissions: \${var.alapaap_default_resource_permissions}

      timeout_seconds: ${timeout}
      health:
        rules:
          - metric: RUN_DURATION_SECONDS
            op: GREATER_THAN
            value: ${healthThr}
      max_concurrent_runs: ${maxConcurrent}
      queue:
        enabled: true
      parameters:
        - name: serverless_cluster_flag
          default: "true"
        - name: reprocessing_list
          default: ""

      tasks:
        - task_key: ${taskKey}
          max_retries: ${maxRetries}
          min_retry_interval_millis: 60000
          notebook_task:
            notebook_path: ../notebooks/${appName}_silver.ipynb
            base_parameters:
              workspace_id: \${var.job_reference.workspace_id}
              workspace_url: \${var.job_reference.workspace_url}
              job_id: \${var.job_reference.job_id}
              job_name: \${var.job_reference.job_name}
              job_trigger_type: \${var.job_reference.job_trigger_type}
              job_run_id: \${var.job_reference.job_run_id}
              job_start_time: \${var.job_reference.job_start_time}
              task_run_id: \${var.job_reference.task_run_id}
              task_name: \${var.job_reference.task_name}
              task_type: "silver"
              task_notebook_path: \${var.job_reference.task_notebook_path}
              execution_env: \${var.job_reference.execution_env}
              execution_type: "bau"
              config_file_path: "${configPath}"
              aws_profile: \${var.aws_profile_name}
              workspace_name: \${var.workspace_name}
              common_package_wheel_path: \${var.common_package_wheel_path}
              consistent_partition_flag: "true"

        - task_key: trigger_downstream_task
          depends_on:
            - task_key: ${taskKey}
          notebook_task:
            notebook_path: ../../common_pipeline_trigger_serverless.ipynb
            base_parameters:
              workspace_id: \${var.job_reference.workspace_id}
              workspace_url: \${var.job_reference.workspace_url}
              job_id: \${var.job_reference.job_id}
              job_name: \${var.job_reference.job_name}
              job_trigger_type: \${var.job_reference.job_trigger_type}
              job_run_id: \${var.job_reference.job_run_id}
              job_start_time: \${var.job_reference.job_start_time}
              task_run_id: \${var.job_reference.task_run_id}
              task_name: \${var.job_reference.task_name}
              task_notebook_path: \${var.job_reference.task_notebook_path}
              execution_env: \${var.job_reference.execution_env}
              upstream_task_name: "${taskKey}"
              config_file_path: "${downstreamPath}"
              is_active: "true"
              check_upstream_flag: "true"
              aws_profile: \${var.aws_profile_name}
              landing_bucket_name: \${var.wde_bucket_name}
              monitoring_bucket_name: \${var.wde_monitoring_bucket_name}
              task_type: "trigger_downstream"
              workspace_name: \${var.workspace_name}
              common_package_wheel_path: \${var.common_package_wheel_path}`;
}

// ── YAML syntax highlighter ───────────────────────────────────────────────────
function highlightYaml(raw) {
  // Escape HTML
  let s = raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  const lines = s.split("\n").map(line => {
    // Comment lines
    if (/^\s*#/.test(line)) {
      return `<span class="yp-comment">${line}</span>`;
    }

    // key: value lines
    return line.replace(
      /^(\s*)([\w_-]+)(\s*:\s*)(.*)$/,
      (_, indent, key, colon, val) => {
        let coloredVal = val;

        // ${var.xxx} interpolations
        coloredVal = coloredVal.replace(
          /(\$\{[^}]+\})/g,
          `<span class="yp-var">$1</span>`
        );

        // <placeholder> markers
        coloredVal = coloredVal.replace(
          /(&lt;[^&]*&gt;)/g,
          `<span class="yp-ph">$1</span>`
        );

        // booleans
        coloredVal = coloredVal.replace(
          /\b(true|false)\b/g,
          `<span class="yp-bool">$1</span>`
        );

        // pure numbers (not inside strings)
        coloredVal = coloredVal.replace(
          /\b(\d+)\b/g,
          `<span class="yp-num">$1</span>`
        );

        // quoted string values
        coloredVal = coloredVal.replace(
          /^(".*")$/,
          `<span class="yp-val">$1</span>`
        );

        return `${indent}<span class="yp-key">${key}</span>${colon}${coloredVal}`;
      }
    );
  });

  return lines.join("\n");
}

// ── Live YAML preview ─────────────────────────────────────────────────────────
function updateYamlPreview() {
  // Keep the mirror input in sync
  const appName = document.getElementById("cfg-pipeline-name")?.value?.trim() || "";
  const dataDomainName = document.getElementById("cfg-datadomain-name")?.value?.trim() || "";
  const mirror  = document.getElementById("yml-pipeline-name-mirror");
  if (mirror) mirror.value = appName;

  // Auto-fill config path placeholders only if user hasn't typed in them
  const cfgPath  = document.getElementById("yml-config-path");
  const downPath = document.getElementById("yml-downstream-config-path");
  if (cfgPath  && cfgPath.dataset.userEdited !== "true")  cfgPath.placeholder  = appName ? `../etc/${appName}_config.json`        : "../etc/<Application_Name>_config.json";
  if (downPath && downPath.dataset.userEdited !== "true") downPath.placeholder = appName ? `./cu/etc/${appName}_config.json` : "./cu/etc/<Application_Name>_config.json";

  const pre  = document.getElementById("yaml-preview");
  const yaml = buildYamlString();
  pre.innerHTML = highlightYaml(yaml);
}

// ── Copy YAML to clipboard ────────────────────────────────────────────────────
function copyYaml() {
  const yaml = buildYamlString();
  navigator.clipboard.writeText(yaml).then(() => {
    const btn = document.querySelector(".btn-copy-yaml");
    btn.textContent = "✓ Copied";
    setTimeout(() => {
      btn.innerHTML = `<svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>Copy`;
    }, 1800);
  });
}

// ── Download jobs.yml ─────────────────────────────────────────────────────────
function downloadYaml() {
  const yaml = buildYamlString();
  const name = document.getElementById("nb-name").value.trim() || "generated_notebook";
  const blob = new Blob([yaml], { type: "text/yaml" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = `${name}_jobs.yml`;
  a.click();
  URL.revokeObjectURL(url);
  setStatus("✓ jobs.yml downloaded!", "success");
}

// ── Generate .ipynb ───────────────────────────────────────────────────────────
async function generate() {
  const btn  = document.getElementById("btn-gen");
  const sql  = document.getElementById("sql-input").value.trim();
  const name = document.getElementById("nb-name").value.trim() || "generated_notebook";

  if (!entries.length) { setStatus("Add at least one source table.", "error"); return; }
  if (!sql)             { setStatus("SQL statement is required.", "error"); return; }

  btn.disabled = true;
  setStatus("Generating...", "");

  try {
    const res = await fetch("/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tables: entries.map(e => ({ table: e.table, partition_col: e.enabled ? e.partition_col : "" })),
        sql,
        name
      })
    });
    if (!res.ok) { const err = await res.json(); throw new Error(err.error || "Server error"); }
    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href     = url;
    a.download = `${name}.ipynb`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus("✓ .ipynb downloaded!", "success");
  } catch (e) {
    setStatus("Error: " + e.message, "error");
  } finally {
    btn.disabled = false;
  }
}

// ── Status helper ─────────────────────────────────────────────────────────────
function setStatus(msg, type) {
  const el = document.getElementById("status-msg");
  el.textContent = msg;
  el.className   = "status" + (type ? " " + type : "");
}

// ── Input events ──────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("tag-input");
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") { e.preventDefault(); commitInput(); }
  });
  input.addEventListener("paste", e => {
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData("text");
    text.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean).forEach(addEntry);
    input.value = "";
  });

  // Render initial previews
  updateJsonPreview();
  updateYamlPreview();

  // Track when user manually edits the config path fields (so auto-fill stops)
  ["yml-config-path", "yml-downstream-config-path"].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener("input", () => {
        el.dataset.userEdited = el.value.trim() ? "true" : "false";
        updateYamlPreview();
      });
    }
  });

  // YAML fields that aren't already wired via oninput
  ["yml-timeout", "yml-health-threshold", "yml-max-concurrent", "yml-max-retries"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", updateYamlPreview);
  });
});