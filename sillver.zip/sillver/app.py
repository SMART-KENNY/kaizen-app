import json
import re
import copy
import uuid
from flask import Flask, request, jsonify, send_file, render_template
import io
import os

app = Flask(__name__)

TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "template.json")
with open(TEMPLATE_PATH) as f:
    TEMPLATE_NB = json.load(f)


@app.route("/")
def index():
    return render_template("index.html")


def table_to_var(table: str) -> str:
    last = table.strip().split(".")[-1]
    last = re.sub(r"[^\w]", "_", last)
    return f"{last}_name"


def var_to_df(var_name: str) -> str:
    if var_name.endswith("_name"):
        return var_name[:-5] + "_df"
    return var_name + "_df"


@app.route("/generate", methods=["POST"])
def generate():
    data = request.json
    table_entries = data.get("tables", [])
    sql = data.get("sql", "").strip()
    name = data.get("name", "generated_notebook").strip()

    if not table_entries:
        return jsonify({"error": "No source tables provided"}), 400
    if not sql:
        return jsonify({"error": "No SQL provided"}), 400

    normalized = []
    for entry in table_entries:
        if isinstance(entry, str):
            normalized.append({"table": entry, "partition_col": "processed_date"})
        else:
            normalized.append({
                "table": entry.get("table", ""),
                "partition_col": entry.get("partition_col", "").strip(),
            })

    tables     = [e["table"] for e in normalized]
    partitions = [e["partition_col"] for e in normalized]
    var_names  = [table_to_var(t) for t in tables]
    df_names   = [var_to_df(v) for v in var_names]

    nb = copy.deepcopy(TEMPLATE_NB)

    # Cell 33: source table variable assignments
    lines_33 = ["# MODIFIED: added bronze source tables\n"]
    for var, table in zip(var_names, tables):
        lines_33.append(f'{var} = "{table}"\n')
    lines_33.append("\n")
    for var in var_names:
        lines_33.append(
            f'{var} = DU.retreive_table_name_by_environment(execution_environment, {var})\n'
        )
    lines_33[-1] = lines_33[-1].rstrip("\n")
    nb["cells"][33]["source"] = lines_33

    # Cell 34: transform_data definition
    fn_params    = ", ".join(df_names)
    sql_indented = "\n".join("            " + line for line in sql.split("\n"))
    cell34_src = (
        "# MODIFIED: added transformation\n\n\n"
        f"def transform_data({fn_params}):\n\n"
        '    df = spark.sql(f"""\n'
        f"{sql_indented}\n"
        '                   """)\n\n'
        "    return df"
    )
    nb["cells"][34]["source"] = [cell34_src]

    # Cell 42: spark.read.table block + transform_data call
    cell42_src = "".join(nb["cells"][42]["source"])

    read_lines = ["# MODIFIED: get source bronze tables, filter by partition\n"]
    for df_var, tbl_var, part_col in zip(df_names, var_names, partitions):
        if part_col:
            read_lines.append(
                f'        {df_var} = spark.read.table({tbl_var}).filter(\n'
                f'            F.col("{part_col}") == F.lit(file_timestamp_str)\n'
                f'        )\n\n'
            )
        else:
            read_lines.append(f'        {df_var} = spark.read.table({tbl_var})\n\n')

    new_read_block = "".join(read_lines).rstrip("\n")

    cell42_src = re.sub(
        r"# MODIFIED: get source bronze tables.*?(?=\n        # MODIFIED:|\n        data_df\s*=)",
        new_read_block + "\n\n        ",
        cell42_src,
        flags=re.DOTALL,
    )

    call_str = f"transform_data({fn_params})"
    cell42_src = re.sub(r"transform_data\([^)]*\)", call_str, cell42_src)
    nb["cells"][42]["source"] = [cell42_src]

    for idx in [33, 34, 42]:
        meta = nb["cells"][idx].get("metadata", {})
        db_meta = meta.get("application/vnd.databricks.v1+cell", {})
        if db_meta:
            db_meta["nuid"] = str(uuid.uuid4())

    nb_bytes = json.dumps(nb, indent=1).encode("utf-8")
    buf = io.BytesIO(nb_bytes)
    buf.seek(0)

    safe_name = re.sub(r"[^\w\-]", "_", name)
    return send_file(
        buf,
        as_attachment=True,
        download_name=f"{safe_name}.ipynb",
        mimetype="application/x-ipynb+json",
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)